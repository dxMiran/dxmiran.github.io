dx_Miran — Official Portfolio

This is a standalone static website.
Open index.html to preview, or upload index.html to a static website host.
All styling and JavaScript are embedded in index.html.

Important:
- The Discord video CDN links were supplied by the site owner. They may expire; replace them with fresh attachment links if they stop working.
- Discord server names/icons that could not be confirmed are marked with numbered placeholders. Replace these with confirmed names and icons.
- The site is static and does not collect visitor information.
- External fonts load from Google Fonts; a system font fallback is provided.
